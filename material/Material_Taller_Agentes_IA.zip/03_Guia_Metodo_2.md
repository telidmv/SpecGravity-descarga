# Guía práctica · Método 2: agentes listos con SpecGravity

Taller SpecGravity · Agentes de Inteligencia Artificial

Esta guía se puede seguir sola, sin la presentación.

**Qué vas a lograr:** instalar el framework SpecGravity, usar agentes que ya vienen preparados (los *starter packs*) con el comando `/exec` y coordinar varios agentes en una sola orden con `/exec batch`.

**Tiempo estimado:** 30 a 40 minutos.

**Este método se hace en vivo con el instructor**, porque la contraseña de descarga se da en la sesión. Antes del taller no tienes que instalar nada de esta guía; solo lo de `00_Requisitos_Previos`.

---

## Qué es SpecGravity

SpecGravity es un **método de trabajo con agentes de IA** convertido en un espacio de trabajo listo para usar. Lo construyó José Paternina Orozco a partir de muchas horas de uso real: entrenamiento, prueba y error, y exploración de distintas herramientas de IA. Lo que funcionó quedó escrito como reglas, plantillas y agentes listos, para que tú no tengas que descubrirlo desde cero.

Funciona así: cada agente vive en su propia carpeta numerada (`P01_Soporte_TI`, `01_Facturacion`…) y tiene escritos, en archivos, su rol, su paso a paso, sus límites y su memoria. Es lo mismo que haces con el Canvas en el Método 1, pero ya organizado, probado y con herramientas para coordinar varios agentes. Tu programa de IA (Claude Code) lee esas reglas y trabaja con ellas.

### Ventajas de usar SpecGravity

| Ventaja | Qué significa para ti |
| :--- | :--- |
| **Gasta menos tokens** (y menos dinero) | El agente lee una especificación corta y clara en lugar de que le expliques todo de nuevo en cada conversación. |
| **Todo ordenado** | Todos los agentes tienen la misma estructura, cada uno en su carpeta. Sabes dónde está cada cosa. |
| **Fácil de usar** | Le hablas en español: `/exec P01` más la tarea. No necesitas programar. |
| **Automatiza lo repetitivo** | Para las tareas que se repiten, el agente construye una automatización una vez; después la automatización hace el trabajo sin IA. Ahorras tiempo, tokens y errores. |
| **Memoria que no se pierde** | Cada agente anota lo que hizo y lo que falta en su `status.md`. Puedes cerrar la conversación y retomar otro día donde quedó. |
| **Seguridad incluida** | Cada agente tiene límites escritos y pide tu aprobación antes de cambiar algo. Además vienen un respaldo diario automático y una revisión semanal de datos sensibles. |
| **Mejora con el uso** | Cada corrección queda como lección, y con `/crecer` el agente te propone mejoras a sus propias reglas. |
| **Varios agentes a la vez** | Con `/exec batch` das una sola orden y cada agente hace su parte. |
| **Resultados fáciles de abrir** | Los agentes entregan informes en HTML, PDF o Excel que abres con doble clic. |
| **No te amarra a una herramienta** | Las mismas carpetas funcionan con Claude Code y con otros programas de agentes. |

### Qué son los *starter packs* y cuáles trae

Un *starter pack* es un **agente ya diseñado y probado**, listo para usar: su Canvas ya está resuelto en sus archivos. Sirven para dos cosas: para usarlos tal cual y como modelo para crear los tuyos.

| Agente | Qué hace | Cómo llega |
| :--- | :--- | :--- |
| `00_Backup` | Copia de seguridad diaria y automática de tus proyectos. | Siempre se instala. |
| `00_Orquestador_Multiagente` | Coordina varios agentes cuando usas `/exec batch`. | Siempre se instala. |
| `P01_Soporte_TI` | Revisa la salud de tu computador (disco, memoria, red) sin cambiar nada sin permiso. | El instalador te pregunta. |
| `P02_Busqueda_Empleo` | Mejora una hoja de vida para los filtros automáticos de selección y redacta cartas de presentación. | El instalador te pregunta. |
| `P03_Generador_Imagenes` | Prepara instrucciones para generar imágenes con una identidad visual coherente. | El instalador te pregunta. |
| `P04_Declaracion_Renta` | Ayuda a organizar y revisar la declaración de renta. | El instalador te pregunta. |

Para el taller, responde **S** (sí) a todos.

### Cómo se numeran los agentes

El número al inicio de cada carpeta dice de quién es el agente, y es el que usas en los comandos:

| Empieza por | Qué es | Ejemplo |
| :--- | :--- | :--- |
| `00_` | Módulos base del framework | `/exec 00_Backup Hacer una copia ahora` |
| `P` | Paquetes listos que trae el framework | `/exec P01 Diagnosticar salud del sistema` |
| `01`, `02`… | **Tus propios agentes**, en el orden en que los crees | `/exec 01 Revisar las facturas de esta semana` |

Así, cuando instales una versión nueva de SpecGravity, sus agentes nunca chocan con los tuyos.

---

## Paso 1 · Descarga SpecGravity (3 minutos)

1. Abre la página de descarga: **[telidmv.github.io/SpecGravity-descarga](https://telidmv.github.io/SpecGravity-descarga/)**.
2. Escribe la **contraseña temporal** que se da en la sesión del taller y presiona **Descargar**.
3. Si el navegador te pregunta dónde guardarlo, elige tu carpeta de trabajo `C:\Agentes`. Si lo guarda solo en *Descargas*, muévelo a `C:\Agentes`.
4. Haz clic derecho sobre el archivo `SpecGravity_v….zip` y elige **Extraer todo…**. Como destino escribe `C:\Agentes\SpecGravity` y presiona **Extraer**.

## Paso 2 · Instala (5 a 10 minutos)

1. Abre la carpeta `C:\Agentes\SpecGravity`.
2. Haz doble clic en **`Instalar_SpecGravity`**.
3. Acepta la solicitud de permisos. Cuando pregunte en qué carpeta instalar, presiona **Enter** para dejarlo ahí mismo.
4. El instalador deja listo todo lo necesario, incluidos los visores para abrir PDF, Excel y Word dentro de VS Code. Cuando te pregunte por cada *starter pack*, responde **S**.
5. Al final, presiona cualquier tecla para cerrar la ventana.

**En un equipo de la empresa**, este paso lo hace o lo autoriza el área de Tecnología.

## Paso 3 · Abre SpecGravity en VS Code (2 minutos)

1. Abre VS Code.
2. Menú **File** (Archivo) › **Open Folder** (Abrir carpeta) › elige `C:\Agentes\SpecGravity`.
3. Abre Claude Code con el ícono de Claude (asterisco naranja), arriba a la derecha.

Claude Code lee automáticamente las reglas de SpecGravity, entre ellas cómo funciona `/exec`.

## Las conversaciones: una por tema y con nombre

Cada vez que le escribes a Claude Code estás en una **conversación** (también se le dice *sesión*). Dos recomendaciones:

1. **Una conversación por tarea o por agente.** Cuando cambies de tema o de agente, empieza una conversación nueva (botón **+** o *Nueva conversación*). En una conversación muy larga la IA empieza a olvidar lo del principio. No pierdes nada al empezar otra: la memoria de cada agente está en su `status.md`.
2. **Ponle nombre.** Al empezar, el agente te propone un nombre listo para copiar: el número del agente, un punto, el número de la conversación y una descripción corta. Por ejemplo, la segunda conversación con el agente de soporte:

   ```text
   /rename P01.2 · Revisión del disco
   ```

   Cópialo, pégalo en la caja de Claude Code y envíalo: la conversación queda con ese nombre y la encuentras rápido en el historial. El agente lleva la cuenta de las conversaciones en su `status.md`, así que no tienes que recordar el número. Las conversaciones que no son de un agente en particular llevan el `00` (por ejemplo `00.1 · Instalación`). Si no te lo propone, pídeselo: *"Propón el nombre de esta conversación."*

## Paso 4 · Dale una tarea a un agente (5 minutos)

En la caja de Claude Code, escribe:

```text
/exec P01 Diagnosticar salud del sistema
```

Este agente solo **revisa** tu equipo (espacio en disco, memoria, red) y te dice qué encontró; no cambia nada sin tu permiso. Si el programa responde que no conoce el comando, escríbelo sin la barra: `exec P01 Diagnosticar salud del sistema`.

`/exec` significa "ejecuta", `P01` es el número del agente (Soporte TI) y lo demás es la tarea en español. Qué va a pasar:

1. El agente lee sus archivos: su rol, su paso a paso, sus límites y su memoria.
2. Anota la tarea en su memoria.
3. Te muestra un plan **antes** de hacer nada. Si un paso puede ser riesgoso, te pide confirmación. Para aprobar, escribe **Aprobado, adelante** (o haz clic en el botón de aceptar si aparece). Aprueba solo lo que entiendas.
4. Ejecuta, comprueba y te deja el resultado como un archivo en su carpeta `entregables`, con el enlace para abrirlo.

Prueba también con el agente de empleo. Primero copia `ejemplos\hoja_de_vida_ejemplo.md` (del material del taller) a la carpeta `P02_Busqueda_Empleo`; es de una persona ficticia, no uses la tuya real:

```text
/exec P02 Revisar la hoja de vida de ejemplo y sugerir mejoras para un cargo de analista administrativo
```

## Paso 5 · Varios agentes en una sola orden (5 minutos)

```text
/exec batch P01 Revisar espacio en disco; 00_Backup Ejecutar copia de seguridad preventiva
```

Las tareas se separan con punto y coma. Cada agente trabaja en su carpeta con sus propias reglas y al final recibes un resumen de lo que hizo cada uno.

## Paso 6 · Mira cómo están hechos (5 minutos)

1. Abre la carpeta `P01_Soporte_TI`.
2. Abre `agent.md` con la vista previa (`Ctrl + Shift + V`).
3. Busca los elementos del Canvas: rol, misión y la lista de lo que tiene **prohibido**.
4. Abre `status.md`: ahí quedó anotada la tarea que le diste en el Paso 4. Esa es su memoria.

Así puedes usar estos agentes como modelo para crear los tuyos.

## Paso 7 · Crea tu propio agente dentro de SpecGravity (opcional)

1. Llena tu Canvas: lo más fácil es en Word (`word\01_Canvas_Agente.docx`, guardado como PDF), o en `.md`. Nómbralo `Canvas_<Area>_<Tarea>`.
2. Copia el archivo del Canvas a `C:\Agentes\SpecGravity`.
3. En Claude Code escribe: *"Crea un nuevo proyecto con el canvas Canvas_Finanzas_Facturas.pdf"* (con el nombre de tu archivo).
4. SpecGravity le asigna el siguiente número libre de **tus** agentes (el primero será `01`), crea sus archivos y te los muestra para aprobar. Desde ahí lo usas con `/exec 01 ...`.

---

## Si algo sale mal

| Qué pasa | Qué hacer |
| :--- | :--- |
| Windows bloquea el instalador | Clic derecho en el archivo › *Propiedades* › marca *Desbloquear* y vuelve a intentarlo. En un equipo de la empresa, pide ayuda a Tecnología. |
| Claude Code no reconoce `/exec` | Verifica que abriste la carpeta `C:\Agentes\SpecGravity` completa. Si sigue igual, escribe: *"Lee AGENTS.md y aplica el protocolo /exec."* |
| No aparece un agente (por ejemplo `P01_Soporte_TI`) | Respondiste **N** cuando el instalador preguntó por ese *starter pack*. Vuelve a hacer doble clic en `Instalar_SpecGravity` y responde **S**. |
| El resultado sale solo en el chat | Dile: *"Guarda el resultado en tus entregables, en un archivo que yo pueda abrir con doble clic."* |
| El agente pide permiso para algo | Es lo esperado. Lee qué va a hacer y aprueba solo si lo entiendes. Si no lo entiendes, pídele: *"Explícamelo sin términos técnicos."* |

## Para llevar a tu trabajo

- Antes de compartir tu carpeta con alguien, haz doble clic en `Auditar_Guardrails`: revisa que no haya datos sensibles.
- **Tu agente crece contigo.** Cuando lo hayas corregido varias veces o tengas una necesidad nueva, escribe `/crecer P01` (con el número del agente): revisa lo que aprendió, te propone mejoras a sus archivos y las aplica solo si las apruebas.
- Para usarlo con información real de tu empresa, hazlo con autorización del área de Tecnología.
