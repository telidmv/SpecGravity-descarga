# Antes del taller: qué necesitas y cómo prepararte

Taller SpecGravity · Agentes de Inteligencia Artificial

Lee esto **antes** del taller. Prepárate con anticipación: si tu computador es de la empresa, pedir permisos puede tomar varios días.

---

## 1. Lo que necesitas

- Un computador con **Windows 10 u 11**. (Si tienes Mac o no te dan permisos, igual puedes seguir el taller mirando la pantalla del instructor.)
- Conexión a internet.
- Una **cuenta de Claude con plan de pago** (Pro o superior). La creas en [claude.ai](https://claude.ai). El modo agente que usamos en el taller no está en el plan gratuito.
- **Permiso para instalar programas.** Si tu computador es de la empresa, lo autoriza el área de Tecnología. Puedes enviarles este mensaje:

  > Hola. Voy a participar en un taller de inteligencia artificial y necesito instalar dos programas: **Visual Studio Code** (code.visualstudio.com) y **Claude de escritorio** (claude.com/download), con la extensión Claude Code. ¿Me pueden ayudar a instalarlos o darme permiso para hacerlo? Practicaré solo con datos de ejemplo. Gracias.

## 2. Los dos programas y para qué sirve cada uno

Un chat normal en el navegador es como hablar por teléfono con alguien: solo sabe lo que le dices o le pegas. Para construir agentes necesitas un programa que trabaje con tus carpetas: que pueda abrir una carpeta que tú le prestes, leer los documentos y dejarte archivos nuevos.

| Programa | Para qué lo usamos | Costo | Dónde se descarga |
| :--- | :--- | :--- | :--- |
| **Visual Studio Code** (VS Code) | El programa donde abres las carpetas y trabajas con los agentes. | Gratis | [code.visualstudio.com/download](https://code.visualstudio.com/download) |
| **Claude Code** (dentro de VS Code) | El agente que lee y crea archivos en tu carpeta. | Incluido en tu plan de Claude | Se instala desde VS Code (paso 3 de abajo) |
| **Claude de escritorio** | El chat, para las prácticas de instrucciones y los asistentes. | Incluido en tu plan de Claude | [claude.com/download](https://claude.com/download) |

### Cómo instalarlos, paso a paso

1. **VS Code.** Entra a [code.visualstudio.com/download](https://code.visualstudio.com/download), haz clic en **Windows** y abre el archivo descargado (queda en tu carpeta *Descargas*). Acepta todo con **Siguiente** hasta **Finalizar**.
2. **Claude de escritorio.** Entra a [claude.com/download](https://claude.com/download), descarga la versión para Windows, ábrela e **inicia sesión** con tu cuenta de Claude.
3. **Claude Code dentro de VS Code.** Abre VS Code. A la izquierda hay una barra con íconos: haz clic en el de **cuadritos** (Extensiones). En el buscador escribe **Claude Code**, elige la de **Anthropic** y haz clic en **Install** (Instalar). Luego inicia sesión con tu cuenta de Claude cuando te lo pida.

Si el computador pide una clave de administrador en cualquiera de estos pasos, es la que tiene el área de Tecnología.

## 3. La prueba de 1 minuto (hazla antes del taller)

1. En tu Escritorio, crea una carpeta nueva llamada **Prueba** y copia dentro **cualquier documento de Word** que no tenga información sensible (o crea uno nuevo que diga "hola").
2. Abre VS Code. Arriba, en el menú **File** (Archivo), elige **Open Folder** (Abrir carpeta) y selecciona la carpeta **Prueba**. Es como adjuntar un archivo a un correo, pero le prestas la carpeta completa.
3. Abre Claude Code: haz clic en el **ícono de Claude** (un asterisco naranja), arriba a la derecha o en la barra de la izquierda. Se abre una caja para escribir.
4. Escribe: **¿qué archivos hay en esta carpeta?**
5. Si te responde con el nombre de tu documento de Word, **estás listo**. No cambia nada: solo mira.

## 4. El material del taller

- **Dónde se descarga:** en [telidmv.github.io/SpecGravity-descarga](https://telidmv.github.io/SpecGravity-descarga/#material), botón **Descargar material**. No necesita contraseña.
- Te llega un archivo `.zip`. Haz clic derecho sobre él y elige **Extraer todo…**. Como destino escribe `C:\Agentes\material`.
- Trae: este documento, la plantilla del Canvas (en Word y en `.md`), las dos guías de práctica y archivos de ejemplo para los ejercicios.

**Cada documento viene en PDF**, en la carpeta `pdf`: si no quieres complicarte, lee los PDF. Los enlaces de los PDF se pueden abrir con un clic.

### Qué es un archivo `.md`

Además de los PDF, el material trae archivos que terminan en `.md` (se llaman *Markdown*). Son documentos de texto con marcas sencillas: un `#` al inicio de una línea es un título y el texto entre `**` va en negrita. La IA los lee muy bien, por eso los agentes guardan sus instrucciones en este formato.

- Para **leerlos con formato**, ábrelos en VS Code y presiona `Ctrl + Shift + V` (vista previa).
- Para **editarlos**, escribe directamente en VS Code o en el Bloc de notas.
- **Si prefieres Word, también sirve.** Lo único que vas a llenar en el taller es el Canvas de tu agente, y viene listo en Word: `word\01_Canvas_Agente.docx`. Ábrelo con doble clic, escribe tus respuestas en los recuadros grises y, al terminar, guárdalo como PDF (*Archivo › Guardar como › Tipo: PDF*). La IA lee Word y PDF sin problema.
- Los demás documentos son para leer: usa sus PDF.

## 5. Tu carpeta de trabajo

Usa **una sola carpeta para todo el taller**. Te recomendamos **`C:\Agentes`**:

1. Abre el Explorador de archivos, entra a **Este equipo**, luego al disco **C:**.
2. Crea una carpeta nueva llamada **Agentes**.

Ahí quedarán el material (`C:\Agentes\material`), los agentes que construyas y, en la segunda práctica, el framework SpecGravity (`C:\Agentes\SpecGravity`).

**Puedes elegir otra carpeta si lo prefieres.** En ese caso, cada vez que las guías digan `C:\Agentes`, usa la tuya. Solo ten en cuenta que, en muchas empresas, el Escritorio y Documentos se sincronizan con OneDrive: los archivos del taller quedarían en la nube corporativa.

## 6. Seguridad y privacidad

- El programa solo ve la carpeta que tú le prestas, y **te pide permiso** antes de cambiar, enviar o borrar algo.
- Lo que el programa lee **se envía al servicio de inteligencia artificial** (Anthropic, la empresa que hace Claude) para procesarlo. Por eso, en el taller **no uses datos reales**: ni cédulas, ni cuentas bancarias, ni datos de clientes. El material trae archivos de ejemplo inventados.
- Si vas a usar lo aprendido con información de tu empresa, primero hazlo con autorización del área de Tecnología.

## 7. Qué haces antes y qué se hace en vivo

| Antes del taller (tú) | En el taller (con el instructor) |
| :--- | :--- |
| Pedir permisos e instalar VS Code, Claude de escritorio y Claude Code. | Ejercicios 1 y 2 y tu primer agente (Método 1). |
| La prueba de 1 minuto. | Descargar e instalar SpecGravity (Método 2): la contraseña se da en la sesión. |
| Descargar y extraer el material en `C:\Agentes\material`. | |

**¿Problemas?** Escríbenos por WhatsApp al [317 218 6586](https://wa.me/573172186586) o al correo [jose.paternina.orozco@hotmail.com](mailto:jose.paternina.orozco@hotmail.com).
