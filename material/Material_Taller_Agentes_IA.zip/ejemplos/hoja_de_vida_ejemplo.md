# Hoja de vida (PERSONA FICTICIA, DATOS DE EJEMPLO)

**Laura Gómez Ejemplo** · Ciudad Ejemplo · laura.ejemplo@correo-ficticio.com

## Perfil
Persona responsable y organizada con experiencia en oficina. Me gusta aprender y trabajar en equipo.

## Experiencia
**Auxiliar administrativa** · Comercializadora Ficticia S.A.S. · 2022 a la fecha
- Manejo de archivo y correspondencia.
- Apoyo en facturación.
- Atención telefónica.

**Recepcionista** · Hotel Imaginario · 2020 a 2022
- Atención a huéspedes.
- Reservas.

## Formación
Técnica en Asistencia Administrativa · Instituto Ejemplo · 2019

## Habilidades
Excel, Word, servicio al cliente, puntualidad.
