# Canvas · Agente de Facturación (ejemplo lleno)

Taller SpecGravity · Ejemplo para practicar. Todos los datos son inventados.

### 1. Nombre (rol)
Agente de Facturación.

### 2. Misión
Soy la administradora de una distribuidora de alimentos. Cada semana llegan facturas de proveedores. Necesito que revises cada factura contra su orden de compra, me digas cuáles cuadran y cuáles no, y me dejes listo el registro de cuentas por pagar.

### 3. Horario o disparador
Cuando yo le pida "revisa las facturas de esta semana".

### 4. Insumos
Copiados en `insumos/`: las facturas de la semana (archivos de texto) y `ordenes_de_compra.csv` con todas las órdenes.

### 5. Paso a paso
1. Leer cada factura y sacar: número, proveedor, orden de compra, cantidad, valor unitario y total.
2. Buscar en `ordenes_de_compra.csv` la orden con ese número.
3. Comparar cantidad, valor unitario y total.
4. Si todo coincide, la factura **cuadra**. Si algo no coincide, **no cuadra**: anotar qué campo y cuánto difiere.

**Comprobación final:** el número de facturas que cuadran más las que no cuadran es igual al número de facturas en `insumos/`, y cada factura que no cuadra tiene su motivo escrito.
**Límite de intentos:** 3. Si no lo logra, se detiene y me pregunta.

### 6. Qué puede hacer y qué NO
- NO puede modificar ni borrar las facturas ni las órdenes de compra.
- NO puede aprobar pagos ni escribir a los proveedores.
- Puede leer `insumos/` y crear archivos en `entregables/`.

### 7. Entregables
1. Un informe en HTML (`entregables/AAAA-MM-DD_revision_facturas.html`) con una tabla: factura, proveedor, orden, ¿cuadra?, motivo.
2. Un Excel `entregables/cuentas_por_pagar.xlsx` solo con las facturas que cuadran.

Ejemplo de buen resultado: "Semana del 6 de octubre: 4 facturas revisadas, 3 cuadran, 1 no cuadra (factura 845 de Papelería El Cuaderno: cobra 210 resmas, la orden OC-101 dice 200)".

### 8. Quién revisa
Yo reviso el informe y apruebo antes de programar los pagos.

### 9. Cómo medimos el éxito
Que todas las facturas queden revisadas sin errores y que la revisión tome menos de 10 minutos.
**Caso de prueba:** con los archivos de esta carpeta, el resultado correcto es 4 revisadas, 3 cuadran, 1 no cuadra (la 845, por cantidad).
