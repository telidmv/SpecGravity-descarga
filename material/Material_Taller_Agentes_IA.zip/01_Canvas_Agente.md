# Canvas de tu agente (9 criterios) · PLANTILLA

Taller SpecGravity · Agentes de Inteligencia Artificial

## Antes de empezar: esto es una plantilla

**No escribas sobre este archivo.** Por cada agente que quieras crear, haz una copia y ponle un nombre que identifique el proyecto:

```text
Canvas_<Area>_<Tarea>
```

Ejemplos: `Canvas_Finanzas_Facturas`, `Canvas_Compras_Cotizaciones`, `Canvas_Personal_Correos`.

- Sin espacios ni tildes en el nombre (usa `_` para separar palabras).
- Si haces una segunda versión, agrega `_v2` al final: `Canvas_Finanzas_Facturas_v2`.
- Guarda tu Canvas **dentro de la carpeta del agente**: así queda junto a sus archivos y la IA lo encuentra.

**¿En qué formato lo lleno?** Tienes dos opciones; elige la que te resulte más cómoda:

- **En Word (lo más fácil si nunca has usado un `.md`).** Abre `word\01_Canvas_Agente.docx` del material: tiene las mismas nueve preguntas con un recuadro para cada respuesta. Guárdalo con el nombre de tu agente, llénalo y, al terminar, guárdalo como PDF (*Archivo › Guardar como › Tipo: PDF*), por ejemplo `Canvas_Finanzas_Facturas.pdf`. La IA lee Word y PDF sin problema.
- **En este mismo formato `.md`.** Un `.md` (*Markdown*) es un documento de texto con marcas sencillas: `#` para títulos y `**` para negrita. Haz una copia del archivo `01_Canvas_Agente.md`, renómbrala (por ejemplo `Canvas_Finanzas_Facturas.md`), ábrela en VS Code y escribe debajo de cada pregunta. Para verlo con formato, presiona `Ctrl + Shift + V`.

Este archivo tiene dos partes:

1. **El Canvas**: nueve preguntas que describen cómo debe trabajar tu agente. Las respondes tú, con tus palabras.
2. **El prompt constructor**: un texto que copias y pegas en tu herramienta de agentes, junto con tu Canvas, para que la IA cree los archivos del agente. Tú revisas y apruebas.

No necesitas saber programar ni conocer de antemano los archivos que se van a crear.

> **Privacidad:** en el Canvas y en los archivos de prueba no pongas datos personales reales (cédulas, cuentas bancarias, teléfonos, nombres de clientes). Usa ejemplos inventados.

---

## Parte 1 · El Canvas

Escribe debajo de cada pregunta. Una o dos frases bastan; si sabes más, escribe más.

### 1. Nombre (rol)
¿Cómo se llama el agente? Usa un nombre de función, no de persona.
*Ejemplo: Agente de Facturación.*

Respuesta:


### 2. Misión
Cuéntale quién eres tú (o qué hace tu empresa) y qué necesitas que haga. Piensa que estás contratando a una persona.
*Ejemplo: Soy la administradora de una distribuidora de alimentos con 40 clientes. Necesito que revises las facturas de proveedores que llegan cada semana, las registres en el Excel de cuentas por pagar y me avises si alguna no cuadra con la orden de compra.*

Respuesta:


### 3. Horario o disparador
¿Cuándo trabaja? ¿Cuando tú se lo pides, todos los días a cierta hora, cuando llega un archivo?
*Ejemplo: Cada lunes, o cuando yo le pida "revisa las facturas de esta semana".*

Respuesta:


### 4. Insumos
¿Con qué información trabaja, en qué formato y dónde está? Tienes dos opciones, y puedes combinarlas:

- **Copiarlos** a la carpeta `insumos/` del agente. Lo más sencillo para empezar y para practicar.
- **Indicar la ruta** donde ya están, por ejemplo `D:\Contabilidad\Facturas 2026`. El agente los lee desde ahí y no los copia. Úsalo cuando los archivos son muy pesados (videos, bases grandes, cientos de PDF) o cuando otra persona los mantiene actualizados. En este caso, di si el agente **solo puede leer** esa carpeta (lo recomendado).

*Ejemplo: Facturas en PDF en `D:\Contabilidad\Facturas 2026` (solo lectura); órdenes de compra en un Excel que copiaré en `insumos/`.*

Respuesta:


### 5. Paso a paso
¿Cómo haces tú hoy esta tarea? Escríbelo en orden, como si le explicaras a alguien nuevo. Termina con dos cosas:

- **La comprobación final.** Es una revisión concreta que el agente hace *antes* de decirte que terminó, para demostrar que el trabajo quedó bien. Que el agente escriba "listo" no prueba nada; la comprobación sí. Piensa en cómo revisarías tú el trabajo de un asistente nuevo: si debía registrar 12 facturas, cuentas que haya 12 filas nuevas en el Excel; si debía sumar, verificas que el total cuadre.
- **El límite de intentos.** Si la comprobación falla, el agente corrige y vuelve a intentar. El límite dice cuántas veces puede hacerlo antes de detenerse y preguntarte qué hacer. Sirve para que no se quede dando vueltas, gastando tiempo, ni "invente" un resultado para salir del paso. Si no sabes qué número poner, usa **3**.

*Ejemplo: 1) Abro cada factura. 2) Busco la orden de compra con el mismo número. 3) Comparo valor y cantidades. 4) Si cuadra, la registro en el Excel. 5) Si no cuadra, la anoto en una lista aparte con el motivo. **Comprobación:** el número de filas nuevas en el Excel más las de la lista aparte es igual al número de facturas. **Intentos:** máximo 3; si no cuadra, me pregunta.*

Respuesta:


### 6. Qué puede hacer y qué NO
Empieza por lo que NO debe hacer. Separa lo que solo **lee** (bajo riesgo) de lo que **cambia o envía algo** (eso siempre espera tu aprobación).

*Ejemplo: NO puede aprobar pagos. NO puede borrar ni modificar las facturas originales. NO puede escribir a los proveedores. Puede leer los insumos libremente. Puede crear archivos en `entregables/`. Cualquier envío o cambio en otro sistema, solo con mi aprobación.*

Respuesta:


### 7. Entregables
¿Qué te entrega al terminar y en qué formato? Pega o describe **dos ejemplos de un buen resultado**: es la forma más rápida de que el agente entienda lo que esperas.

*Ejemplo: El Excel de cuentas por pagar actualizado y un resumen así: "Semana del 3 de marzo: 12 facturas, 11 registradas, 1 no cuadra (factura 845 de Papelería El Cuaderno: cobra 210 resmas, la orden dice 200)".*

Respuesta:


### 8. Quién revisa
¿Quién valida el resultado antes de usarlo?
*Ejemplo: Yo reviso el resumen y apruebo antes de programar los pagos.*

Respuesta:


### 9. Cómo medimos el éxito
Empieza con algo que ya mides o que es fácil de contar. Y prepara **casos de prueba**: entre 5 y 10 ejemplos reales del pasado (sin datos sensibles) con la respuesta correcta. El agente debe acertar un mínimo antes de usarlo en serio.

*Ejemplo: Todas las facturas de la semana registradas sin errores; revisión en menos de 30 minutos (antes, 3 horas). **Casos de prueba:** las facturas de 5 semanas pasadas con su resultado correcto; debe acertar las 5.*

Respuesta:


---

## Después de construirlo (no es un criterio, es una rutina)

- **Cada semana**, revisa algunas tareas que hizo el agente.
- **Cuando corrijas un error**, basta con decirle al agente qué estuvo mal. Él mismo lo anota en `lecciones.md` (qué pasó y qué regla aprendió) y lo agrega como un caso de prueba nuevo.
- **Cada vez que cambien** sus instrucciones, pídele que vuelva a correr los casos de prueba.

---

## Cómo se convierte tu Canvas en archivos

No tienes que crear estos archivos a mano: los crea la IA con el prompt constructor. La tabla es para que entiendas qué hay en cada uno cuando los revises.

| Archivo o carpeta | Para qué sirve | Sale de los criterios |
| :--- | :--- | :--- |
| `README.md` | Puerta de entrada: qué hace el agente y cómo pedirle cosas. | 1 y 2 |
| `agent.md` | Quién es el agente, su misión y sus límites. **El más importante de revisar.** | 1, 2 y 6 |
| `skill.md` | El procedimiento paso a paso, con la comprobación final y el límite de intentos. | 5 |
| `spec.md` | El contrato: reglas de negocio, entregables, ejemplos de buen resultado y cuándo está bien hecho. | 6, 7 y 9 |
| `status.md` | La memoria viva: horario, tareas hechas y pendientes, validaciones, métricas. | 3, 8 y 9 |
| `references.md` | Dónde están los insumos (copiados o con su ruta) y las plantillas de entregables. | 4 y 7 |
| `glossary.md` | Las palabras y siglas de tu negocio. | Todo el Canvas |
| `lecciones.md` | Errores corregidos y la regla aprendida. Máximo una página. | Rutina semanal |
| `pruebas/casos_de_prueba.md` | Los casos de prueba con su respuesta correcta. | 9 |
| `insumos/` | Archivos de entrada que copies. Si los insumos están en otra ruta, aquí no va nada. | 4 |
| `entregables/` | Lo que produce el agente, en un formato que se abre con doble clic: informe en HTML (navegador), PDF, Excel o Word. | 7 |
| `automatizaciones/` | Solo si el agente construye una automatización: los archivos que la ejecutan y un `LEEME.md` que explica, en palabras sencillas, cómo usarla. | 5 |

---

## Parte 2 · Prompt constructor

1. Guarda tu Canvas lleno (Word, PDF o `.md`) **dentro de la carpeta del agente**. Así queda guardado junto al agente y no se pierde.
2. Abre esa carpeta en VS Code y abre Claude Code.
3. Copia todo el bloque de abajo, pégalo y, en la última línea, cambia `[NOMBRE DE TU ARCHIVO]` por el nombre de tu Canvas (por ejemplo `Canvas_Finanzas_Facturas.pdf`).

```text
Actúa como arquitecto de agentes con la metodología SpecGravity (Spec-DD: el agente trabaja a partir de especificaciones escritas).

Con el Canvas que pego al final, vas a crear en la carpeta abierta la estructura de un agente:

- README.md: qué hace el agente, para quién, y 3 ejemplos de cómo pedirle tareas.
- agent.md: rol, misión y una sección "LÍMITES (PROHIBIDO)" con todo lo del criterio 6, escrito como prohibiciones claras. Separa "puede leer" de "necesita aprobación para cambiar o enviar". Incluye siempre: no modificar archivos fuera de esta carpeta, no borrar ni modificar insumos originales, no escribir en rutas externas de insumos, y pedir confirmación antes de cualquier acción que no se pueda deshacer.
- skill.md: el procedimiento paso a paso del criterio 5, numerado. El último paso es la comprobación de que el resultado existe y es correcto. Incluye el límite de intentos y qué hacer si algo falla o falta información.
- spec.md: objetivo, reglas de negocio, entregables con su formato, los dos ejemplos de buen resultado del criterio 7 y los criterios de éxito del criterio 9.
- status.md: horario o disparador (criterio 3), quién revisa (criterio 8), métricas (criterio 9), una lista de tareas pendientes y una bitácora vacía con columnas Fecha | Tarea | Resultado | Comprobación | Validado por.
- references.md: dónde están los insumos (criterio 4). Si son rutas externas, anótalas como "solo lectura" y no copies esos archivos. Incluye las plantillas o formatos de los entregables.
- glossary.md: los términos y siglas del negocio que aparecen en el Canvas, con una definición corta.
- lecciones.md: vacío, con la explicación "Errores corregidos y regla aprendida. Máximo una página. Léelo al inicio de cada tarea."
- pruebas/casos_de_prueba.md: una tabla Entrada | Resultado esperado | Último resultado | ¿Pasa?, con los casos del criterio 9 si los di.
- Carpetas insumos/ y entregables/ con un archivo LEEME.txt que explique qué va en cada una.
- En agent.md, deja escritas estas reglas de trabajo:
  * El resultado final siempre va en entregables/ en un formato que yo pueda abrir con doble clic: HTML para informes y comparativos, PDF para documentos, Excel para datos. Al terminar, dime qué produjiste y cómo abrirlo.
  * Si una tarea se repite con pasos fijos, propón una automatización. Sus archivos van en una carpeta automatizaciones/ con un LEEME.md que explique en palabras sencillas qué hace y cómo se usa.
  * Mantén la carpeta ordenada: nada de archivos sueltos de prueba o temporales.
  * Háblame sin términos técnicos. Si hay que decidir algo técnico, elige lo más sencillo y seguro, explícamelo en una frase y pide mi aprobación.
  * Tú llevas tu memoria: al terminar cada tarea, anótala en status.md con su comprobación; si te corrijo, anota la lección en lecciones.md y agrega el caso a pruebas/. Yo no edito esos archivos.

Reglas para ti:
1. Antes de crear nada, muéstrame el plan: la lista de archivos y un resumen de qué irá en cada uno.
2. Dime qué información le falta o queda ambigua en el Canvas y pregúntame. No inventes datos.
3. Escribe en español sencillo, sin tecnicismos innecesarios.
4. No uses datos personales reales; si necesitas ejemplos, invéntalos y márcalos como ejemplo.
5. Espera mi aprobación explícita antes de crear los archivos.
6. Al terminar, dime cómo darle su primera tarea de prueba.

Mi Canvas está en el archivo [NOMBRE DE TU ARCHIVO] de esta carpeta.
```

---

## Si no sabes por dónde empezar

Pégale este Canvas vacío a cualquier chat de IA y dile: *"Quiero crear un agente para [tu tarea]. Hazme preguntas, una por una, para llenar estos nueve criterios."* Cuando lo tengas lleno, pídele: *"¿Qué puntos débiles ves en este diseño? ¿Qué no estoy teniendo en cuenta?"*
