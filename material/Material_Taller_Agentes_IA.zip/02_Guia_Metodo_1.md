# Guía práctica · Método 1: tu agente desde cero

Taller SpecGravity · Agentes de Inteligencia Artificial

Esta guía se puede seguir sola, sin la presentación. Si estás en la sesión en vivo, el instructor hace los mismos pasos en pantalla.

**Qué vas a lograr:**
1. **Ejercicio 1, una tarea:** la IA compara tres cotizaciones y recomienda una.
2. **Ejercicio 2, una automatización:** la IA te deja lista una automatización que, con doble clic, ordena facturas por mes y arma un resumen.
3. **Tu propio agente**, con el Canvas.

**Tiempo estimado:** 60 a 90 minutos en total.

**Antes de empezar:** revisa `00_Requisitos_Previos`. Necesitas VS Code con Claude Code instalado y funcionando.

---

## Lo mínimo que hay que entender

**Asistente y agente.** Un asistente (un chat) responde cuando le escribes y trabaja con lo que le pegas. Un agente trabaja hacia un objetivo, lee y crea archivos en una carpeta y sigue unas reglas escritas.

**Tarea y automatización.** En una **tarea**, la IA *piensa*: lee, compara, redacta (ejercicio 1). En una **automatización**, se repiten *pasos fijos* siempre igual y no hace falta IA al ejecutarlos; la IA solo te ayuda a construirla una vez (ejercicio 2).

**Los 4 filtros para elegir qué tarea convertir en agente.** Una buena candidata pasa los cuatro:

| Filtro | Pregunta | Si la respuesta es "no"… |
| :--- | :--- | :--- |
| 1. Frecuencia | ¿Se repite seguido (cada día, semana o mes) y te quita tiempo? | Si es una vez al año, no vale la pena. |
| 2. Reglas claras | ¿Podrías explicarle a alguien nuevo cómo se hace, paso a paso? | Primero escribe el procedimiento. |
| 3. Información digital | ¿Lo que entra y lo que sale está en archivos, correos o sistemas? | Digitaliza primero (una foto de un papel también sirve). |
| 4. Costo del error | Si el agente se equivoca, ¿lo notarías a tiempo y podrías corregirlo antes de que cause un problema, como un pago mal hecho o un correo enviado a un cliente? | Empieza por otra tarea donde un error no tenga consecuencias graves. |

**La regla de oro:** el agente hace el trabajo pesado y **tú revisas y apruebas**. Siempre.

**Dónde ves los resultados.** No esperes la respuesta solo en el chat. Lo importante queda como un **archivo** en la carpeta `entregables`, en la lista de archivos de VS Code, a la izquierda. Los informes salen en HTML (se abren en el navegador), PDF o Excel: haz doble clic, o clic derecho y *Abrir*.

---

## Preparación (5 minutos)

1. Descomprime el material del taller en la carpeta `C:\Agentes\material` (o en la carpeta que elegiste).
2. Verifica que existe la carpeta `ejemplos\` con tres subcarpetas: `ejercicio_1_cotizaciones`, `ejercicio_2_facturas` y `ejercicio_3_agente_facturacion`. Todos los datos son inventados.

---

## Por qué los ejercicios 1 y 2 no usan el Canvas

Los dos primeros ejercicios son de **calentamiento**: le das la instrucción a la IA directamente en un mensaje, para ver cómo trabaja con tus archivos. Ese mensaje ya contiene, en pequeño, lo mismo que pide el Canvas:

| En el mensaje | Criterio del Canvas |
| :--- | :--- |
| "Eres mi analista de compras" | 1 y 2 · Rol y misión |
| "En la carpeta insumos hay…" | 4 · Insumos |
| Los pasos numerados | 5 · Paso a paso |
| "No modifiques… no lo inventes" | 6 · Lo que NO puede hacer |
| "Guarda el resultado en…" | 7 · Entregables |

La diferencia: un mensaje se usa una vez y se pierde en la conversación. El Canvas queda **escrito** en la carpeta del agente, y el agente lo vuelve a leer cada vez que trabaja. Eso es lo que harás en la tercera parte.

---

## Ejercicio 1 · Una tarea: comparar cotizaciones (15 minutos)

**La situación:** tres proveedores cotizaron 200 resmas de papel, cada uno a su manera. Uno no calculó el total y otro cotiza por cajas con IVA incluido. Quieres saber cuál conviene.

1. Crea la carpeta `C:\Agentes\Agente_Cotizaciones` y, dentro, una carpeta `insumos`.
2. Copia los tres archivos de `ejemplos\ejercicio_1_cotizaciones` a `insumos`.
3. Abre `C:\Agentes\Agente_Cotizaciones` en VS Code (*Archivo › Abrir carpeta*) y abre Claude Code.
4. Escribe este mensaje:

   ```text
   Eres mi analista de compras. En la carpeta insumos hay tres cotizaciones del mismo producto.
   1. Calcula el total final de cada una con IVA, en pesos y para 200 resmas. Muestra el cálculo.
   2. Haz una tabla comparativa: total, tiempo de entrega, forma de pago, garantía y riesgos.
   3. Recomienda una y explica por qué en tres líneas.
   Reglas: no modifiques los archivos de insumos. Si un dato no está, escribe "NO INDICA", no lo inventes.
   Antes de escribir el resultado, muéstrame tu plan.
   Guarda el resultado como un informe que yo pueda abrir con doble clic en entregables/comparativo.html.
   ```

5. Lee el plan que te propone. Si estás de acuerdo, escribe **Aprobado, adelante** (o haz clic en el botón de aceptar si aparece).
6. Abre el informe: en la lista de archivos de la izquierda, entra a `entregables` y haz clic derecho sobre `comparativo.html` › *Abrir en el navegador* (o doble clic desde el Explorador de Windows).
7. **Comprueba el resultado tú mismo** antes de creerle. Los totales correctos son: A $4.403.000, B $3.888.920 (200 × $17.200, menos 5%, más IVA), C $3.840.000.
8. Pregúntale: *"¿Qué riesgos tiene elegir la más barata?"*. Fíjate si menciona el anticipo y que el precio de C está sujeto a disponibilidad.

**Lo que aprendiste:** la IA piensa con información desordenada, pero tú compruebas. Si se equivocó en un total, ya sabes por qué el paso de comprobación es obligatorio.

---

## Ejercicio 2 · Una automatización: ordenar facturas (15 minutos)

**La situación:** cada mes llegan facturas a una misma carpeta, revueltas. Quieres que, con un doble clic, queden en subcarpetas por mes y con un resumen que se abra en Excel.

1. Crea la carpeta `C:\Agentes\Automatizacion_Facturas` y, dentro, `insumos`.
2. Copia las siete facturas de `ejemplos\ejercicio_2_facturas` a `insumos`.
3. Abre `C:\Agentes\Automatizacion_Facturas` en VS Code y abre Claude Code.
4. Escribe este mensaje:

   ```text
   Quiero una automatización que no use IA cuando se ejecute: con un doble clic,
   las facturas de la carpeta insumos deben quedar ordenadas en subcarpetas por mes,
   y debe crearse un resumen que yo pueda abrir en Excel con la fecha, el proveedor y el total de cada factura.
   Al final debe decirme cuántas facturas ordenó.
   Guarda los archivos de la automatización en una carpeta llamada automatizaciones,
   con instrucciones de uso en palabras sencillas.
   Reglas: no borres ninguna factura, solo muévela. Si una factura no tiene fecha, déjala donde está y avísame.
   Antes de crearla, explícame en palabras sencillas qué va a hacer y espera mi aprobación.
   Si tienes que decidir algo técnico, elige lo más sencillo y explícamelo sin términos técnicos.
   ```

5. Lee la explicación. Si estás de acuerdo, escribe **Aprobado, adelante**.
6. Haz **una copia de la carpeta `insumos`** por si acaso.
7. Abre la carpeta `automatizaciones` y haz doble clic en el archivo que te indique la IA (sus instrucciones de uso lo dicen).
8. **Comprueba:** deben quedar tres subcarpetas (2026-08 con 3 facturas, 2026-09 con 3 y 2026-10 con 1) y un resumen con 7 filas.
9. Copia otra factura de ejemplo a `insumos` y vuelve a hacer doble clic: se ordena sola. Eso es una automatización.

**Lo que aprendiste:** la IA te ayudó a construirla una vez; después corre siempre igual, sin IA, sin costo y sin sorpresas. Muchas "tareas de agente" en realidad son automatizaciones.

> **En un equipo de la empresa**, ejecuta solo automatizaciones que entiendas y que Tecnología haya autorizado.

---

## Tu propio agente con el Canvas (30 a 45 minutos)

**¿No tienes todavía una tarea tuya con archivos de prueba?** Usa el caso de ejemplo `ejemplos\ejercicio_3_agente_facturacion`: trae un Canvas ya lleno (`Canvas_Finanzas_Facturas.md`), facturas de ejemplo y las órdenes de compra, y su resultado correcto está en el `LEEME.txt`. Sigue los mismos pasos usando esos archivos.

### Paso 1 · Llena el Canvas (10 minutos)

1. Escoge una tarea tuya que pase los **4 filtros** de la tabla de arriba.
2. Llena el Canvas. Lo más fácil es **en Word**: abre `word\01_Canvas_Agente.docx`, escribe en los recuadros y guárdalo como PDF. También puedes usar la plantilla `.md`. Ponle un nombre con la forma `Canvas_<Area>_<Tarea>`, por ejemplo `Canvas_Finanzas_Facturas.pdf`.
3. Dedica más tiempo al criterio 6 (lo que NO debe hacer) y al 5 (la comprobación final).

### Paso 2 · Crea la carpeta del agente (2 minutos)

1. Crea una carpeta vacía con el nombre del agente, por ejemplo `C:\Agentes\Agente_Facturacion`.
2. Guarda tu Canvas dentro de esa carpeta.
3. Ábrela en VS Code y abre Claude Code.

### Paso 3 · Pega el prompt constructor (5 minutos)

1. Copia el bloque del **prompt constructor** de la Parte 2 de `01_Canvas_Agente`.
2. Pégalo y, en la última línea, cambia `[NOMBRE DE TU ARCHIVO]` por el nombre de tu Canvas.
3. La IA te mostrará un plan y te hará preguntas. Respóndelas.
4. Cuando el plan te parezca bien, escribe: **"Aprobado, crea los archivos."**

### Paso 4 · Revisa los archivos (10 minutos)

Ábrelos con la vista previa (`Ctrl + Shift + V` en VS Code). Pon atención a:

- `agent.md`: ¿están todos los límites? Si falta uno, díselo: *"Agrega a tus límites que no puedes…"*.
- `skill.md`: ¿el paso a paso es como tú lo haces? ¿Termina con una comprobación?
- `references.md`: ¿quedaron bien las rutas de tus insumos?

Los archivos **son** el agente: cuando cambian, cambia su comportamiento. Los cambios se los pides al agente en lenguaje normal; no tienes que editarlos tú.

### Paso 5 · Primera tarea de prueba (10 minutos)

1. **Archivos de prueba:** pon en `insumos/` los ejemplos que preparaste para el criterio 9 del Canvas (casos del pasado, sin datos sensibles). Si usas el caso de ejemplo, copia ahí los archivos de `ejercicio_3_agente_facturacion\insumos`. Estos no son los archivos de los ejercicios 1 y 2.
2. Pídele la tarea: *"Procesa lo que hay en insumos siguiendo tus instrucciones."*
3. Antes de actuar debe explicarte su plan. Apruébalo si estás de acuerdo.
4. Abre el resultado en `entregables` y compáralo con el resultado correcto que esperabas. ¿Hizo la comprobación final?
5. Si algo estuvo mal, díselo en una frase. El agente registra la tarea en su memoria (`status.md`) y anota la corrección en `lecciones.md` por su cuenta: así lo dejó escrito el prompt constructor.

---

## Si algo sale mal

En todos los casos, **díselo al agente**: él actualiza sus propios archivos y te muestra el cambio para que lo apruebes.

| Qué pasa | Qué le dices al agente |
| :--- | :--- |
| Inventó datos que no estaban | *"Inventaste datos. Agrega a tus reglas que si un dato no está en los insumos escribas 'NO INDICA' y nunca lo inventes."* |
| Hizo algo que no le pediste | *"No debías hacer [eso]. Agrégalo a tus límites."* |
| Dice "listo" pero el resultado está incompleto | *"El resultado está incompleto. Agrega al final de tu paso a paso una comprobación concreta, por ejemplo contar que haya una fila por cada factura."* |
| Se queda dando vueltas | *"Agrega un límite: máximo 3 intentos; si no lo logras, detente y pregúntame."* |
| Te pregunta todo el tiempo | Es normal al principio. Cuando confíes en un paso: *"El paso [X] lo puedes hacer sin preguntarme."* |
| El resultado sale solo en el chat y no como archivo | *"Guarda siempre el resultado en entregables, en un archivo que yo pueda abrir con doble clic."* |
| No encuentro Claude Code en VS Code | Busca el ícono de Claude (asterisco naranja) arriba a la derecha. Si no está, revisa el paso 3 de la instalación en `00_Requisitos_Previos`. |
| Windows no deja abrir el archivo de la automatización | Clic derecho sobre el archivo › *Propiedades* › marca *Desbloquear*. En un equipo de la empresa, pide ayuda a Tecnología. |

## Para llevar a tu trabajo

- Empieza con una sola tarea pequeña y con archivos de prueba.
- Trabaja con una carpeta antes de conectar el agente a tu correo o a otros sistemas.
- Valida siempre lo que entrega. Cuando un paso lleve semanas sin errores, puedes darle más autonomía en ese paso.
- Cada semana revisa algunas tareas. Cuando corrijas algo, díselo: el agente lo anota en `lecciones.md` y en sus casos de prueba.
